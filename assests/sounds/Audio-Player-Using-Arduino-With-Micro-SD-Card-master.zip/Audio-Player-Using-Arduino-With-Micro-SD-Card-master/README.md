# Audio-Player-Using-Arduino-With-Micro-SD-Card
Many of People want to interface the SD card with arduino or want some audio output via arduino.  So here is easiest and cheapest way to interface SD card with arduino . you can use the audio output from arduino via a switch or sensor .  you can play any type of sound ,music and recording but that audio will be in to .wav file. If it is in .mp3 or any other audio type then we will convert it into .wav file.

watch video :- https://youtu.be/dV9dB435gaE

For more check my youtube channel :- http://youtube.com/vishalsoniindia
